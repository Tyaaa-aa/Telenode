<!DOCTYPE html>
<html>
<!-- HEAD CONTENT -->
<?php include "head.php" ?>
<body>
<!-- HEADER CONTENT -->
<?php include "header.php" ?>
<!-- BODY CONTENT BELOW -->



<!-- FOOTER CONTENT -->
<?php include "footer.php" ?>
</body>
</html>

