<div>
    Hello <?= $getUserName ?>. This is the
    <br><br>
    <h2>Community</h2>
</div>