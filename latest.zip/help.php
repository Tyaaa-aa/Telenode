<div>
    Hello <?= $getUserName ?>. This is the
    <br><br>
    <h2>Help</h2>
</div>