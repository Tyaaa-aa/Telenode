<footer>
    FOOTER
    <script src="js/script.js?v=<?= time() ?>"></script>
</footer>
<?php
// if ($hasVid) {
//     echo $getVid_id, $getVid_userID, $getVid_URLS;
// }
?>