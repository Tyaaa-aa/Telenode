# ISBVOSP
Easy and cost-free way to produce interactive videos that would be made available online so that content designers can share learning globally
